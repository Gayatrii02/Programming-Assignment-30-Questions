# Question 26: Determine ticket price based on age category.
# Below 5: Free, 5-12: Rs 100, 13-59: Rs 200, 60 and above: Rs 120

age = int(input("Enter age: "))

if age < 0:
    print("Invalid age.")
elif age < 5:
    print("Ticket price: Free")
elif age <= 12:
    print("Ticket price: Rs 100")
elif age <= 59:
    print("Ticket price: Rs 200")
else:
    print("Ticket price: Rs 120")
