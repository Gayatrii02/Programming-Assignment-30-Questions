# Question 28: Check if a person is eligible for a driving license (age and eyesight).

age = int(input("Enter your age: "))
eyesight = input("Is your eyesight good? (yes/no): ").lower()

if age >= 18 and eyesight == "yes":
    print("You are eligible for a driving license.")
elif age < 18:
    print("Not eligible: you must be at least 18 years old.")
else:
    print("Not eligible: eyesight condition not met.")
