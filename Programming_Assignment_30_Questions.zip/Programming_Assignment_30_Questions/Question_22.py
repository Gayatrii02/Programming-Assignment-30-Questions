# Question 22: Check if a year is a century leap year.

year = int(input("Enter a year: "))

if year % 100 != 0:
    print(year, "is not a century year.")
elif year % 400 == 0:
    print(year, "is a century leap year.")
else:
    print(year, "is a century year but not a leap year.")
