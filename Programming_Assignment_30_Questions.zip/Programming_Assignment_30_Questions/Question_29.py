# Question 29: Login system with username and password validation.
# Username: admin, Password: 1234

username = input("Enter username: ")
password = input("Enter password: ")

if username == "admin" and password == "1234":
    print("Login successful.")
elif username != "admin":
    print("Invalid username.")
else:
    print("Incorrect password.")
