# Question 18: Calculate income tax based on income slabs.
# Up to 3,00,000: 0%, 3,00,001-6,00,000: 5%, 6,00,001-9,00,000: 10%,
# 9,00,001-12,00,000: 15%, above 12,00,000: 20%

income = float(input("Enter annual income: "))

if income < 0:
    print("Invalid income.")
else:
    if income <= 300000:
        tax = 0
    elif income <= 600000:
        tax = (income - 300000) * 0.05
    elif income <= 900000:
        tax = 300000 * 0.05 + (income - 600000) * 0.10
    elif income <= 1200000:
        tax = 300000 * 0.05 + 300000 * 0.10 + (income - 900000) * 0.15
    else:
        tax = 300000 * 0.05 + 300000 * 0.10 + 300000 * 0.15 + (income - 1200000) * 0.20
    print("Income tax: Rs", tax)
