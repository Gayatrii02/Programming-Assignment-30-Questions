# Question 11: Check if a character is uppercase or lowercase.

ch = input("Enter a character: ")

if len(ch) != 1 or not ch.isalpha():
    print("Please enter a single alphabet letter.")
elif ch.isupper():
    print(ch, "is uppercase.")
else:
    print(ch, "is lowercase.")
