# Programming Assignment - 30 Questions

**Language:** Python 3

## Files

Question_01.py to Question_30.py - one file per question (topics: conditions, operators, simple loops).

## How to Run in VS Code

1. Install Python 3 from https://www.python.org (tick "Add Python to PATH").
2. Install the **Python** extension in VS Code.
3. Open VS Code > File > Open Folder > select `Programming_Assignment_30_Questions`.
4. Open any `Question_XX.py` file and click the **Run** (play) button, or run in the terminal:

```
python Question_01.py
```

## Notes

Questions 17, 18, 25, 26, 27 and 29 do not give exact rates or values, so sample ones are used (written in the comment at the top of each file). Change them if your trainer gave different values.
