# Question 23: Determine the season based on the month number.

month = int(input("Enter month number (1-12): "))

if month == 12 or month == 1 or month == 2:
    print("Season: Winter")
elif month >= 3 and month <= 5:
    print("Season: Spring")
elif month >= 6 and month <= 8:
    print("Season: Summer")
elif month >= 9 and month <= 11:
    print("Season: Autumn")
else:
    print("Invalid month number.")
