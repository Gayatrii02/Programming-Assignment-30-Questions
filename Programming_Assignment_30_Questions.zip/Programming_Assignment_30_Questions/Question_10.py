# Question 10: Assign grades based on marks.
# 90-100: A, 80-89: B, 70-79: C, 60-69: D, below 60: F

marks = float(input("Enter marks (0-100): "))

if marks < 0 or marks > 100:
    print("Invalid marks.")
elif marks >= 90:
    print("Grade: A")
elif marks >= 80:
    print("Grade: B")
elif marks >= 70:
    print("Grade: C")
elif marks >= 60:
    print("Grade: D")
else:
    print("Grade: F")
