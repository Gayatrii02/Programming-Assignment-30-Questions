# Question 12: Find whether the entered alphabet is a vowel using if-elif.

ch = input("Enter an alphabet: ").lower()

if ch == "a":
    print("It is a vowel.")
elif ch == "e":
    print("It is a vowel.")
elif ch == "i":
    print("It is a vowel.")
elif ch == "o":
    print("It is a vowel.")
elif ch == "u":
    print("It is a vowel.")
else:
    print("It is not a vowel.")
