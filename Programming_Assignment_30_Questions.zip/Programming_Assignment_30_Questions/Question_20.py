# Question 20: Find whether a number is within a given range.

low = float(input("Enter lower limit: "))
high = float(input("Enter upper limit: "))
num = float(input("Enter the number: "))

if low > high:
    print("Lower limit cannot be greater than upper limit.")
elif low <= num <= high:
    print(num, "is within the range.")
else:
    print(num, "is not within the range.")
