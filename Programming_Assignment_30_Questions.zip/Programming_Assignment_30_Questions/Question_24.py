# Question 24: Find the number of days in a month.

month = int(input("Enter month number (1-12): "))

if month == 2:
    year = int(input("Enter the year: "))
    if (year % 4 == 0 and year % 100 != 0) or year % 400 == 0:
        print("Number of days: 29")
    else:
        print("Number of days: 28")
elif month == 4 or month == 6 or month == 9 or month == 11:
    print("Number of days: 30")
elif month == 1 or month == 3 or month == 5 or month == 7 or month == 8 or month == 10 or month == 12:
    print("Number of days: 31")
else:
    print("Invalid month number.")
