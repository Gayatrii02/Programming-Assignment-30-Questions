# Question 17: Calculate electricity bill using slab rates.
# First 100 units: Rs 5, next 100 units: Rs 7, above 200 units: Rs 10

units = int(input("Enter units consumed: "))

if units < 0:
    print("Invalid units.")
else:
    if units <= 100:
        bill = units * 5
    elif units <= 200:
        bill = 100 * 5 + (units - 100) * 7
    else:
        bill = 100 * 5 + 100 * 7 + (units - 200) * 10
    print("Electricity bill: Rs", bill)
