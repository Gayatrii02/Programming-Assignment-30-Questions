# Question 19: Check if a student passes (minimum 35 marks in each subject).

m1 = float(input("Enter marks of subject 1: "))
m2 = float(input("Enter marks of subject 2: "))
m3 = float(input("Enter marks of subject 3: "))

if m1 >= 35 and m2 >= 35 and m3 >= 35:
    print("The student has passed.")
else:
    print("The student has failed.")
