# Question 25: Check whether a password meets minimum conditions.
# At least 8 characters, one digit, one uppercase, one lowercase letter.

password = input("Enter a password: ")

has_digit = False
has_upper = False
has_lower = False

for ch in password:
    if ch.isdigit():
        has_digit = True
    elif ch.isupper():
        has_upper = True
    elif ch.islower():
        has_lower = True

if len(password) < 8:
    print("Weak password: must have at least 8 characters.")
elif not has_digit:
    print("Weak password: must have at least one digit.")
elif not has_upper:
    print("Weak password: must have at least one uppercase letter.")
elif not has_lower:
    print("Weak password: must have at least one lowercase letter.")
else:
    print("Password is valid.")
