# Question 16: Check whether a number is a three-digit number.

num = int(input("Enter a number: "))

if 100 <= abs(num) <= 999:
    print(num, "is a three-digit number.")
else:
    print(num, "is not a three-digit number.")
