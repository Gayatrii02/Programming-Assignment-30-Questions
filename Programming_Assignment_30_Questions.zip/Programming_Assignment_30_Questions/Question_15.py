# Question 15: Find the largest among four numbers.

a = float(input("Enter first number: "))
b = float(input("Enter second number: "))
c = float(input("Enter third number: "))
d = float(input("Enter fourth number: "))

if a >= b and a >= c and a >= d:
    print("Largest number is", a)
elif b >= a and b >= c and b >= d:
    print("Largest number is", b)
elif c >= a and c >= b and c >= d:
    print("Largest number is", c)
else:
    print("Largest number is", d)
