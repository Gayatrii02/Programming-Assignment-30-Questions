# Question 27: Calculate discount based on purchase amount.
# 5000 or more: 20%, 3000-4999: 10%, 1000-2999: 5%, below 1000: none

amount = float(input("Enter purchase amount: "))

if amount < 0:
    print("Invalid amount.")
else:
    if amount >= 5000:
        discount = amount * 0.20
    elif amount >= 3000:
        discount = amount * 0.10
    elif amount >= 1000:
        discount = amount * 0.05
    else:
        discount = 0
    final = amount - discount
    print("Discount: Rs", discount)
    print("Final amount: Rs", final)
